# SPICE and XSPICE tutorial work plan

Research started: 12 November 2026. These are standalone manual-ready bundles,
not replacements for the removed curriculum packs.

## Research and design decisions

- [x] Read the [official ngspice tutorial index](https://ngspice.sourceforge.io/tutorials.html) and [beginner tutorial](https://ngspice.sourceforge.io/ngspice-tutorial.html). Use the operating-point → transient → small-signal AC progression, with TinyCAD instructions and original circuits/explanations.
- [x] Read the [control-language tutorial](https://ngspice.sourceforge.io/ngspice-control-language-tutorial.html). Teach reproducible sweeps and measurements through TinyCAD's supported controls; distinguish command-line ngspice features from TinyCAD features.
- [x] Read the [XSPICE introduction](https://ngspice.sourceforge.io/xspice.html) and [XSPICE HOWTO](https://ngspice.sourceforge.io/xspicehowto.html). Separate continuous analogue voltages from event-driven digital nodes and introduce explicit ADC/DAC bridges.
- [x] Locate the [ngspice reference manual](https://ngspice.sourceforge.io/docs.html) for source syntax, analysis definitions and code-model parameters. Check exact model interfaces against the bundled ngspice source and execute the resulting examples.
- [x] Inspect `D:\Projects\TinyCAD\examples\AMP.DSN`: retain its two-transistor topology, R1–R6, C1/C2, volume control, 12 V rail and 8 ohm load; replace drawing-only parts with embedded simulation components. Record all model substitutions.
- [x] Establish engine scope from TinyCAD's build configuration: native XSPICE code models are bundled; WASM explicitly disables XSPICE. Do not present behavioural SPICE gates as event-driven XSPICE.
- [x] Audit supported analysis controls, measurement definitions, chart units and result retention before writing UI steps.

## Shared introduction

- [x] How to use the tutorials: finding bundled examples, opening editable copies, following lessons, interpreting reference results, saving and resetting experiments.

## SPICE course — eleven pages

- [x] 01 Overview and first run: workflow, node 0, models, units and a voltage divider.
- [x] 02 DC voltage, current and power: polarity, differential measurements, loading and a DC sweep.
- [x] 03 Signal generators: DC, sine, pulse, triangle, PWL, exponential, FM, current and controlled sources; AC excitation is separate.
- [x] 04 Transients: RC charging, timestep, initial conditions and settling.
- [x] 05 AC frequency response: RC filter, gain, phase, decibels and cutoff.
- [x] 06 Nonlinear circuits: diode rectification, smoothing, ripple and model limits.
- [x] 07 Rebuild AMP.DSN: topology crosswalk, bias and model assumptions.
- [x] 08 Amplifier gain and bandwidth: frequency response, loading and small-signal limits.
- [x] 09 Amplifier output and power: transient gain, clipping, RMS, supply power and efficiency.
- [x] 10 Design investigations: parameter sweeps, tolerances, noise/transfer/pole-zero features, convergence and reproducible reporting.
- [x] 11 TinyCAD implementation: bundled ngspice/XSPICE, desktop/browser differences, symbol selection, run workflow, model attachments, results and diagnosis.

## Separate XSPICE/digital course

- [x] 01 Overview: analogue versus digital modelling and desktop prerequisites.
- [x] 02 Gates and truth tables: explicit bridges and logic levels.
- [x] 03 Timing: propagation delay, rise/fall times and hazards.
- [x] 04 Sequential logic: D flip-flops, clocks, reset and initial state.
- [x] 05 Counters and divided clocks: expected state sequence and measurement.
- [x] 06 Mixed-signal application: digital waveform through a DAC bridge into an RC filter; thresholds, unknown states and limitations.

## Build and acceptance

- [x] Build reusable tutorial-generation/verification tooling independently of deleted teaching code.
- [x] Each page directs users to named embedded examples with symbols/models and saved analysis settings, through TinyCAD's Open Example browser.
- [x] Use compact, upright layouts, native wire segments and correct junctions; verify save/reopen connectivity.
- [x] Run every supplied analysis on the bundled engine and check numerical results against equations or explicit tolerances.
- [x] Record measured amplifier bias, gain, bandwidth and power rather than inventing expected numbers.
- [x] Include readable circuit images and result plots; capture actual TinyCAD UI screenshots for operation instructions, with honest captions distinguishing plots from screenshots.
- [x] Inspect every figure and verify every Markdown link.
- [x] Provide source references, navigation, model provenance, verification results and a portable ZIP bundle.
- [x] Run relevant tests/typecheck and update this checklist with completed work and any concrete limitations.
